/* Hello World program
	
	CSE 220 T/TH 10:30
	Jackson Curless
	Dylan Coyle
	Phillip Day
*/

#include <stdio.h> 

int main() //program starts at main
{
	printf("Hello World!\n"); //prints "Hello World!" to the console with a return
	printf("CSE 220 is awesome!\n"); //prints "CSE 220 is awesome!" to the console
	printf("This is some text. \n"); //prints some text;)
	return 0;
}
